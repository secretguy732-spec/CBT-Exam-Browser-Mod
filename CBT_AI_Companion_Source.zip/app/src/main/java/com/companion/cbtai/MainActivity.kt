package com.companion.cbtai

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    data class AiApp(
        val name: String,
        val packageName: String,
        val website: String,
        val description: String
    )

    private val aiApps = listOf(
        AiApp("ChatGPT", "com.openai.chatgpt", "https://chatgpt.com", "Asisten AI dari OpenAI"),
        AiApp("Gemini", "com.google.android.apps.bard", "https://gemini.google.com", "Asisten AI dari Google"),
        AiApp("Microsoft Copilot", "com.microsoft.copilot", "https://copilot.microsoft.com", "Asisten AI Microsoft"),
        AiApp("DeepSeek", "com.deepseek.chat", "https://chat.deepseek.com", "Asisten AI DeepSeek"),
        AiApp("Claude", "com.anthropic.claude", "https://claude.ai", "Asisten AI Anthropic"),
        AiApp("Perplexity", "ai.perplexity.app.android", "https://www.perplexity.ai", "AI untuk pencarian dan jawaban")
    )

    private val bg = Color.rgb(15, 17, 29)
    private val panel = Color.rgb(27, 30, 47)
    private val accent = Color.rgb(124, 102, 255)
    private val muted = Color.rgb(169, 174, 197)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun rounded(color: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius
        }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        val eyebrow = text("AI COMPANION", 12, accent, true)
        root.addView(eyebrow)
        root.addView(text("AI Assistant", 30, Color.WHITE, true).apply {
            setPadding(0, dp(6), 0, dp(4))
        })
        root.addView(text("Buka aplikasi AI yang sudah terpasang di perangkatmu.", 14, muted, false))

        val info = TextView(this).apply {
            text = "Gunakan aplikasi ini di luar sesi ujian atau ketika penggunaan AI memang diizinkan."
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = rounded(Color.rgb(47, 42, 82), 18f)
        }
        root.addView(info, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(22)
            bottomMargin = dp(20)
        })

        root.addView(text("Aplikasi AI", 18, Color.WHITE, true).apply {
            setPadding(0, 0, 0, dp(12))
        })

        aiApps.forEach { app ->
            root.addView(makeAppCard(app), LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(11)
            })
        }

        root.addView(text("Aplikasi tidak muncul?", 16, Color.WHITE, true).apply {
            setPadding(0, dp(18), 0, dp(6))
        })
        root.addView(text(
            "Daftar ini berisi layanan AI yang didukung. Jika aplikasinya belum terpasang, tombol akan membuka situs resminya melalui browser.",
            13, muted, false
        ))
        root.addView(text("CBT AI Companion • 1.0", 11, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(28), 0, 0)
        })
    }

    private fun makeAppCard(app: AiApp): View {
        val installed = packageManager.getLaunchIntentForPackage(app.packageName) != null
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(panel, 20f)
            isClickable = true
            isFocusable = true
        }

        val icon = ImageView(this).apply {
            val drawable = try {
                packageManager.getApplicationIcon(app.packageName)
            } catch (_: Exception) { null }
            if (drawable != null) setImageDrawable(drawable)
            else {
                setImageResource(android.R.drawable.sym_def_app_icon)
                setColorFilter(accent)
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)))

        val labels = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), 0, dp(8), 0)
        }
        labels.addView(text(app.name, 16, Color.WHITE, true))
        labels.addView(text(
            if (installed) "Terpasang • ${app.description}" else "Buka versi web • ${app.description}",
            11, muted, false
        ))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))

        val action = TextView(this).apply {
            text = if (installed) "BUKA" else "WEB"
            textSize = 11f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(13), dp(9), dp(13), dp(9))
            background = rounded(accent, 30f)
        }
        row.addView(action)

        row.setOnClickListener { openAi(app) }
        return row
    }

    private fun openAi(app: AiApp) {
        val launch = packageManager.getLaunchIntentForPackage(app.packageName)
        try {
            if (launch != null) {
                startActivity(launch)
            } else {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(app.website)))
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak dapat membuka ${app.name}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
